def hello(event, context):
    print("Hi Sai Snigdha Reddy G, How are you")